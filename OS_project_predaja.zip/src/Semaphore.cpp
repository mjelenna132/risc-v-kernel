//
// Created by jelena on 8/19/26.
//
#include "../inc/Semaphore.hpp"
#include "../inc/MemoryAllocator.hpp"
#include "../inc/Scheduler.hpp"

_sem::_sem(unsigned init)
    : value(init),
      blockedHead(nullptr),
      blockedTail(nullptr),
      closed(false)
{
}
// Poziv new _sem(init) automatski poziva ovaj operator sa
// size = sizeof(_sem), kako bi rezervisao memoriju za novi objekat.
void* _sem::operator new(size_t size) noexcept
{
    // Pretvaramo veličinu objekta iz bajtova u blokove.
    size_t blockCount = size / MEM_BLOCK_SIZE;

    if (size % MEM_BLOCK_SIZE != 0) {
        blockCount++;
    }

    return MemoryAllocator::mem_alloc(blockCount);
}

void _sem::operator delete(void* ptr) noexcept
{
    MemoryAllocator::mem_free(ptr);
}

int _sem::open(_sem** handle, unsigned init)
{
    // Potrebna nam je adresa na koju upisujemo ručku.
    if (handle == nullptr) {
        return -1;
    }

    *handle = new _sem(init);

    // Nema dovoljno memorije za objekat semafora.
    if (*handle == nullptr) {
        return -2;
    }

    return 0;
}

void _sem::addBlocked(_thread* thread)
{
    // Nova nit postaje poslednja u redu.
    thread->next = nullptr;

    // Red je prazan.
    if (blockedTail == nullptr) {
        blockedHead = thread;
        blockedTail = thread;
    } else {
        // Stari poslednji pokazuje na novu nit.
        blockedTail->next = thread;
        blockedTail = thread;
    }
}

_thread* _sem::removeBlocked()
{
    // Niko ne čeka.
    if (blockedHead == nullptr) {
        return nullptr;
    }

    // Uzimamo prvu nit.
    _thread* thread = blockedHead;
    blockedHead = blockedHead->next;

    // Ako smo uklonili jedinu nit, red je sada prazan.
    if (blockedHead == nullptr) {
        blockedTail = nullptr;
    }

    thread->next = nullptr;
    return thread;
}

int _sem::wait()
{
    return waitN(1);
}

int _sem::signal()
{
    return signalN(1);
}

int _sem::close(_sem* handle)
{
    // Ne postoji semafor koji treba ugasiti.
    if (handle == nullptr) {
        return -1;
    }

    // Semafor više ne sme da se koristi.
    handle->closed = true;

    // Budimo sve niti koje su čekale.
    _thread* thread = handle->removeBlocked();

    while (thread != nullptr) {
        thread->blocked = false;

        // Wait vraća grešku jer je semafor ugašen.
        thread->waitResult = -1;
        thread->waitUnits = 0;

        Scheduler::put(thread);

        thread = handle->removeBlocked();
    }

    // Oslobađamo memoriju objekta semafora.
    delete handle;

    return 0;
}

int _sem::waitN(unsigned n)
{
    // Ne može se čekati na zatvorenom semaforu (dosledno sa
    // signalN, koji na isti način prvo proverava zatvorenost).
    if (closed) {
        return -1;
    }

    // Čekanje nula jedinica uvek uspeva.
    if (n == 0) {
        return 0;
    }

    // Ima dovoljno dostupnih jedinica.
    if (value >= n) {
        value -= n;
        return 0;
    }

    // Nema dovoljno: tekuća nit se blokira.
    _thread* current = _thread::running;

    current->blocked = true;
    current->waitResult = 0;
    current->waitUnits = n;

    addBlocked(current);

    // Pokreće se neka druga spremna nit.
    _thread::dispatch();

    // Kada se ova nit probudi, nastavlja odavde.
    return current->waitResult;
}

bool _sem::tryWait()
{
    // Ne blokira: ako trenutno nema resursa (ili je semafor
    // zatvoren), samo se vraća bez čekanja u redu.
    if (closed || value == 0) {
        return false;
    }

    value--;
    return true;
}

int _sem::signalN(unsigned n)
{
    if (closed) {
        return -1;
    }

    // Signaliziranje nula jedinica ništa ne menja.
    if (n == 0) {
        return 0;
    }

    // Dodajemo n dostupnih jedinica.
    value += n;

    // Budimo niti redom, dok imamo dovoljno resursa.
    while (blockedHead != nullptr &&
           value >= blockedHead->waitUnits) {

        _thread* awakened = removeBlocked();

        // Nit dobija onoliko jedinica koliko je tražila.
        value -= awakened->waitUnits;

        awakened->blocked = false;
        awakened->waitResult = 0;
        awakened->waitUnits = 0;

        // Vraćamo probuđenu nit među spremne niti.
        Scheduler::put(awakened);
    }

    return 0;
}